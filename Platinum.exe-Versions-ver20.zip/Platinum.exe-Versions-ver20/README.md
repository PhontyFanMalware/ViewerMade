# Platinum.exe-Versions
the versions of Platinum. Its Safe.
